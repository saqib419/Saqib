const { verifyToken } = require('../utils/jwt');
const User = require('../models/User');

const protect = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'No token provided.' });
    }

    const token = header.split(' ')[1];
    const decoded = verifyToken(token);

    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }

    if (!user.isActive) {
      return res.status(401).json({ success: false, message: 'This account has been suspended.' });
    }

    // NEW: if a role/permission change happened after this token was issued,
    // permissionVersion on the token no longer matches the live DB value —
    // reject and force re-login so the user picks up the new permissions.
    // (Tokens signed before this change won't have this field; treat
    // `undefined` as version 1 so existing sessions aren't broken by the
    // upgrade itself.)
    const tokenVersion = decoded.permissionVersion ?? 1;
    if (tokenVersion !== user.permissionVersion) {
      return res.status(401).json({ success: false, message: 'Session expired due to a permission change. Please log in again.' });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token.' });
  }
};

// Unchanged — your existing simple role-gate, still works for existing routes.
const restrictTo = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ success: false, message: 'Not authorized for this resource.' });
  }
  next();
};

module.exports = { protect, restrictTo };
