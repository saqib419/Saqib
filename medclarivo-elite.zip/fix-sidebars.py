import json, base64, re, urllib.request

TOKEN = "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"
OWNER = "Mmahinbhat"
REPO  = "medclarivo-elite"

# filename -> which nav item should be marked active
PAGES = {
    "admin-dashboard.html":   "dashboard",
    "admin-users.html":       "users",
    "admin-mentors.html":     "mentors",
    "admin-students.html":    "students",
    "admin-assignments.html": "assignments",
    "admin-permissions.html": "permissions",
    "admin-audit.html":       "audit",
    "admin-profile.html":     "profile",
}

def nav_html(active_key):
    def cls(key):
        return "nav-item active" if key == active_key else "nav-item"
    return f'''<nav class="flex-1 px-0 py-2 space-y-1 overflow-y-auto">
      <a class="{cls("dashboard")}" href="admin-dashboard.html"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
      <a class="{cls("users")}" href="admin-users.html"><i data-lucide="users"></i><span>Users</span></a>
      <a class="{cls("mentors")}" href="admin-mentors.html"><i data-lucide="graduation-cap"></i><span>Mentors</span></a>
      <a class="{cls("students")}" href="admin-students.html"><i data-lucide="user-check"></i><span>Students</span></a>
      <a class="{cls("assignments")}" href="admin-assignments.html"><i data-lucide="clipboard-list"></i><span>Assignments</span></a>
      <a class="nav-item" href="admin-calendar.html"><i data-lucide="calendar"></i><span>Calendar</span></a>
      <a class="nav-item" href="admin-session-notes.html"><i data-lucide="notebook-pen"></i><span>Session Notes</span></a>
      <a class="nav-item" href="admin-evaluations.html"><i data-lucide="star"></i><span>Evaluations</span></a>
      <a class="nav-item" href="#" onclick="showToast('Content Library coming soon')"><i data-lucide="library"></i><span>Content Library</span></a>
      <a class="nav-item" href="#" onclick="showToast('Messaging coming soon')"><i data-lucide="message-circle"></i><span>Messaging</span></a>
      <a class="nav-item" href="#" onclick="showToast('Payments coming soon')"><i data-lucide="credit-card"></i><span>Payments</span></a>
      <a class="nav-item" href="#" onclick="showToast('Reports coming soon')"><i data-lucide="bar-chart-3"></i><span>Reports</span></a>
      <a class="{cls("permissions")}" href="admin-permissions.html"><i data-lucide="shield"></i><span>Permissions</span></a>
      <a class="{cls("audit")}" href="admin-audit.html"><i data-lucide="scroll-text"></i><span>Audit Log</span></a>
      <a class="{cls("profile")}" href="admin-profile.html"><i data-lucide="user-circle"></i><span>Profile</span></a>
    </nav>'''

def gh_get(path):
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{REPO}/contents/{path}",
        headers={"Authorization": f"token {TOKEN}", "User-Agent": "MedClarivo"}
    )
    with urllib.request.urlopen(req) as r:
        data = json.load(r)
        content = base64.b64decode(data["content"]).decode()
        return content, data["sha"]

def gh_put(path, content, sha, msg):
    payload = {"message": msg, "content": base64.b64encode(content.encode()).decode(), "sha": sha}
    req = urllib.request.Request(
        f"https://api.github.com/repos/{OWNER}/{REPO}/contents/{path}",
        data=json.dumps(payload).encode(), method="PUT",
        headers={"Authorization": f"token {TOKEN}", "Content-Type": "application/json", "User-Agent": "MedClarivo"}
    )
    with urllib.request.urlopen(req) as r:
        json.load(r)

NAV_RE = re.compile(r'<nav\b[^>]*>.*?</nav>', re.DOTALL)
for path, active_key in PAGES.items():
    try:
        content, sha = gh_get(path)
    except Exception as e:
        print(f"SKIP {path}: could not fetch ({e})")
        continue

    new_nav = nav_html(active_key)
    if NAV_RE.search(content):
        new_content = NAV_RE.sub(lambda m: new_nav, content, count=1)
    else:
        print(f"WARNING {path}: nav block pattern not found, skipped")
        continue

    if new_content == content:
        print(f"NO CHANGE {path}")
        continue

    gh_put(path, new_content, sha, f"Fix sidebar: add Calendar/Session Notes/Evaluations links to {path}")
    print(f"updated: {path}")

print("done")
